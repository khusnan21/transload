<html>
	<head>
		<title>www.MyTechBlog.in</title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>
	<body>
		<div class="Links">
		<h1>PHP script for downloading</h1>
		<!--------------------------------------------------------
				All Links
		---------------------------------------------------------->
		
		1. <a href="LinkUploadToServer.php">Download file to the server with a link</a><br><br>
		2. <a href="FormUploadToGoogleDrive.php">Upload file to Google Drive</a><br><br>
			
		</div>
	</body>
</html>