<?php
$upload_services[] = 'sendit.cloud';
$max_file_size['sendit.cloud'] = 4048;
$page_upload['sendit.cloud'] = 'sendit.cloud.php';
?>
